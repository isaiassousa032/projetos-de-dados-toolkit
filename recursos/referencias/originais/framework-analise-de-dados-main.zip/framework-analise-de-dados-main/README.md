# Método de Análise de Dados

Repositório com **guias e modelos reutilizáveis** para estruturar análises de dados do entendimento à decisão.

O objetivo é manter um processo **simples, consistente e independente de ferramentas** (SQL, Python, Power BI, Excel etc.).

---

## Fluxo do método

```text
Dados / Problema
      ↓
   ENTENDER
      ↓
   ANALISAR
      ↓
  COMUNICAR
      ↓
   DECISÃO
```

1. **Entender** — compreender problema e dados
2. **Analisar** — investigar hipóteses com evidências
3. **Comunicar** — transformar em insights e recomendações

---

## Estrutura

```text
metodo-analise-de-dados/
├── guias/
├── templates/
└── exemplos/
```

---

# 1. Entender

Antes de analisar, é preciso entender **o que os dados representam e qual problema será resolvido**.

## Guia

[`guia-primeiras-perguntas.md`](guias/guia-primeiras-perguntas.md)

Perguntas essenciais:

- Qual o problema de negócio?
- O que uma linha representa?
- Qual a granularidade?
- Quais são as chaves e métricas?
- Existem limitações ou inconsistências?

## Modelo

[`modelo-diagnostico-inicial.docx`](modelos/modelo-diagnostico-inicial.docx)

---

# 2. Analisar

Fluxo de investigação:

```text
Problema → Pergunta → Hipóteses → Evidências → Insights → Recomendações → Decisão
```

## Guia

[`framework-analise-de-dados.md`](guias/framework-analise-de-dados.md)

Inclui:

- definição da pergunta
- hipóteses
- validação
- evidências
- insights e recomendações

## Modelo

[`modelo-framework-analise.docx`](modelos/modelo-framework-analise.docx)

---

# 3. Comunicar

Transformar análise em decisão:

> O que foi descoberto, por que importa e o que fazer.

## Modelo

[`modelo-resumo-executivo.docx`](modelos/modelo-resumo-executivo.docx)

Inclui:

- problema e objetivo
- insights principais
- evidências
- recomendações
- próximos passos

---

# Como usar

1. **Entender** → usar guia + diagnóstico inicial
2. **Analisar** → usar framework + modelo de análise
3. **Comunicar** → usar resumo executivo

---

# Exemplos

A pasta [`exemplos/`](exemplos/) contém aplicações reais do método.

---

# Princípios

- **Não começar pela ferramenta** → comece pelo problema
- **Número precisa de contexto** → sempre comparar
- **Insight = achado + impacto + recomendação**
- **Análise termina quando responde a pergunta inicial**

---

## Regra mental

```text
Por quê? → problema
O quê? → dados
Quem/Onde/Quando? → contexto
Quanto? → métricas
Comparado a quê? → referência
Por quê aconteceu? → hipóteses
E daí? → decisão
```

---

## Objetivo

Um método pessoal que evolui com a prática:

> **Entender → Analisar → Comunicar → Decidir**
